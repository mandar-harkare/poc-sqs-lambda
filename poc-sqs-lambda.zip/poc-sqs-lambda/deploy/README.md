# Docker Images & Jenkinsfiles

  * *_The directory Jenkins contains the test, build & deploy job 'Jenkinsfile', for the ERS._*


* Deploy the SQS Requests Queue & Policies

  * Path to Job: Jenkins/GHE-CPT/edge-response-service
    * Runs upon commit of a feature branch to the ERS Repo
    * Can be built with parameter
